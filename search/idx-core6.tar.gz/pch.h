#define _FILE_OFFSET_BITS 64
#define _LARGE_FILE_SOURCE
#define _LARGEFILE64_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <stddef.h>
#include <errno.h>
#include <assert.h>
#include <time.h>
#include <malloc.h>
#include <string.h>
#include <memory.h>
#include <ctype.h>
#include <pthread.h>
